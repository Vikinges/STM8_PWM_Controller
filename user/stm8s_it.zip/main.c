/**
  ******************************************************************************
  * @file    TIM2_PWM_DutyCycleConfiguration\main.c
  * @author  MCD Application Team
  * @version V2.0.4
  * @date     26-April-2018
  * @brief   This file contains the main function for TIM2 PWM_DutyCycleConfiguration
  *          example.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; COPYRIGHT 2014 STMicroelectronics</center></h2>
  *
  * Licensed under MCD-ST Liberty SW License Agreement V2, (the "License");
  * You may not use this file except in compliance with the License.
  * You may obtain a copy of the License at:
  *
  *        http://www.st.com/software_license_agreement_liberty_v2
  *
  * Unless required by applicable law or agreed to in writing, software 
  * distributed under the License is distributed on an "AS IS" BASIS, 
  * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  * See the License for the specific language governing permissions and
  * limitations under the License.
  *
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/
#include "stm8s.h"

/**
  * @addtogroup TIM2_PWM_DutyCycleConfiguration
  * @{
  */

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/
/* Evalboard I/Os configuration */

#define PWM_GPIO_PORT  (GPIOC)
#define PWM_GPIO_PINS  (GPIO_PIN_3 | GPIO_PIN_4 )
//#define LED_PWM (CCR2_Val)
//#define PWM_col (CCR3_Val)
/* Private macro -------------------------------------------------------------*/
/* Private variables communications ------------------------------------------*/
uint16_t speed = 125; // variable speed cooller 
/* Private variables tim2 ----------------------------------------------------*/
//uint16_t CCR1_Val = 125;   //pin PD4 
//uint16_t CCR2_Val = 10;  // pin PD3 led pwm
//uint16_t CCR3_Val = 200;   // pin  PA3 Cooler
uint16_t ADC_Vol = 1000 ; // volium tart size 
/* Private function prototypes -----------------------------------------------*/
void TIM2_Config(void);
/* Private functions ---------------------------------------------------------*/
void Delay (uint16_t nCount);
/* Public functions ----------------------------------------------------------*/

/**
  * @brief  Main program.
  * @param  None
  * @retval None
  */
void main(void)
{
  /* TIM2 configuration -----------------------------------------*/
 // TIM2_Config(LED_PWM); 
  /* Initialize I/Os in Output Mode */
  GPIO_Init(PWM_GPIO_PORT, (GPIO_Pin_TypeDef)PWM_GPIO_PINS, GPIO_MODE_OUT_PP_LOW_FAST);
 GPIO_Init(GPIOD,GPIO_PIN_3,GPIO_MODE_OUT_PP_HIGH_FAST);
  while (1)
  GPIO_WriteLow(GPIOC,GPIO_PIN_3);
   GPIO_WriteLow(GPIOD,GPIO_PIN_3);
    Delay(1000);  
    GPIO_WriteHigh(GPIOC,GPIO_PIN_3);
 GPIO_WriteHigh(GPIOD,GPIO_PIN_3);
  if (ADC_Vol > 1)
  {
    --ADC_Vol;
  }
 else  
    {ADC_Vol = 100;
      }
  

 
 
/*   if ( PWM_col < 998 )
    {
      ++ PWM_col ;
       Delay(100); 
    }
    else {
        PWM_col = 100; 
 
    }
*/
 {}
}

/**
  * @brief Delay
  * @retval None
  */


/**
  * @brief  Configure TIM2 peripheral in PWM mode
  * @param  None
  * @retval None
  */
// void TIM2_Config()
//{
//  /* Time base configuration */
//  TIM2_TimeBaseInit(TIM2_PRESCALER_1, 999);
//
//  /* PWM1 Mode configuration: Channel1 */ 
//  TIM2_OC1Init(TIM2_OCMODE_PWM1, TIM2_OUTPUTSTATE_ENABLE,CCR1_Val, TIM2_OCPOLARITY_HIGH);
//  TIM2_OC1PreloadConfig(ENABLE);
//
//  /* PWM1 Mode configuration: Channel2 */ 
//  TIM2_OC2Init(TIM2_OCMODE_PWM1, TIM2_OUTPUTSTATE_ENABLE,LED_PWM, TIM2_OCPOLARITY_HIGH);
//  TIM2_OC2PreloadConfig(ENABLE);
//
//  /* PWM1 Mode configuration: Channel3 */         
//  TIM2_OC3Init(TIM2_OCMODE_PWM1, TIM2_OUTPUTSTATE_ENABLE,PW M_col, TIM2_OCPOLARITY_HIGH);
//  TIM2_OC3PreloadConfig(ENABLE);
//
//  TIM2_ARRPreloadConfig(ENABLE);
//
//  /* TIM2 enable counter */
//  TIM2_Cmd(ENABLE);
//}


void Delay(uint16_t nCount)
{
  /* Decrement nCount value */
  while (nCount != 0)
  {
    nCount--;
  }
}

#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param file: pointer to the source file name
  * @param line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/**
  * @}
  */


/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
